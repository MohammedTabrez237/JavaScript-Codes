console.log("Hello from first line")


function hello(){
    console.log('Hello from inside the function')
}

hello()

console.log("Hello from the last line")