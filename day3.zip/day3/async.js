console.log("Hello from the first line")

setTimeout(()=>{
    console.log('Hello from the call back fn')
},3000)

console.log("Hello from the last line")